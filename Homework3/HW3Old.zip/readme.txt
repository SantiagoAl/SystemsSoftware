Name: Alex Santiago
UCF ID: 3216767
November 05, 2020
COP 3402 Fall 2020

Directions to compile and run Assignment 3
	1. First unzip the zip file which contains all of the files needed to
	   run and execute the compiler.
	2. Now, you can use the 'Makefile' contained in the zip file to easily
	   compile the project.
	3. Simple type into the command line --> make
	4. make <-- will compile all of the .c files. After this you should see 
	   on your screen:
	   gcc -O3 -Wall    -c driver.c
	   gcc -O3 -Wall    -c lex.c
	   gcc -O3 -Wall    -c parser.c
	   gcc -O3 -Wall    -c codegen.c
	   gcc -O3 -Wall    -c vm.c
	   gcc -o src_prog -O3 -Wall   driver.o lex.o parser.o codegen.o vm.o -lm
	   -----------DONE WITH SRC_PROG-----------
	   my work is done here...
	5. This means that is has successfully compiled, and it created an executable
	   called --> src_prog
	6. BEWARE: If you use the 'input.txt' file that I have provided, it will ask
	   the user for input.
	7. Now, to run the program, simply type --> ./src_prog
	8. You will need to provide an input file to the program. So, you can do this
	   like so --> ./src_prog input.txt
	9. Lastly, you will need to provide compiler directives to see output from the
	   program. To see a full run from the program you can do the following
	   --> ./src_prog input.txt -l -a -v

	10. After doing all of this it will create a bunch of '-o' files and the
	    'src_prog' file. To clean this all up and get rid of these files, simply
	    type at the command line --> make clean

Information about what is included:
	1. First, unzip the zip file which contains all of the files needed to
	   run and execute the compiler.
	2. The major files are 'driver.c', 'lex.c', 'parser.c', 'codegen.c',
	   and 'vm.c', along with all of the respective '.h' files.
	3. Also included is an 'input.txt', which you can use to test the
	   compiler. There is also an 'inputToScanner.txt' file that I used to
	   test the program, and an 'OutputOfParserCodegen.txt' file which
	   contains the run of that test.
	4. Also contained in the zip file is a 'Makefile' file to make it easier
	   to compile all of these .c files.
	5. Lastly, in the zip file there is an 'OutputOfPossibleErrors.txt' file
	   that shows the possible errors that can come from the parser.